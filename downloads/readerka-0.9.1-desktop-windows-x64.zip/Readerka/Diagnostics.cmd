@echo off
setlocal
"%~dp0runtime\bin\java.exe" -Dfile.encoding=UTF-8 -cp "%~dp0lib\*" org.readerka.desktop.MainKt %*
pause
