@echo off
setlocal
start "" "%~dp0runtime\bin\javaw.exe" -Dfile.encoding=UTF-8 -cp "%~dp0lib\*" org.readerka.desktop.MainKt %*
